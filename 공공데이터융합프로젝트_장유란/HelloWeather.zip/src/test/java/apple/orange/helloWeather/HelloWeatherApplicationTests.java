package apple.orange.helloWeather;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloWeatherApplicationTests {

	@Test
	void contextLoads() {
	}

}
