package apple.orange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HelloWeatherApplication {
//https://github.com/JYuRan/reportWeather.git
	public static void main(String[] args) {
		SpringApplication.run(HelloWeatherApplication.class, args);
	}

}
